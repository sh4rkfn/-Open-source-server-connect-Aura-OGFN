#include "pch.h"
#include "base.h"

namespace Starfall {
	namespace Globals {
		void* buf;
		void* EOSBuf;

		void* tbuf;
		size_t tsize;

		void* rbuf;
		size_t rsize;

		void* EOSTextBuf;
		size_t EOSTextSize;

		void* EOSRDataBuf;
		size_t EOSRDataSize;
	}
};