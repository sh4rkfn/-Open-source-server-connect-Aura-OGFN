# Starfall
## Starfall has been replaced by [Tellurium](https://github.com/plooshi/Tellurium).

Starfall is an universal SSL bypass / redirect for native UE HTTP games, made for Fortnite. <br>

# Configuring Starfall

## Changing Starfall's Backend URL.
To change Starfall's backend URL to yours, go to ``Starfall/opts.h`` and change the ``Backend`` variable to your backend's URL.

## Build for a Hybrid
Go to ``Starfall/opts.h``, and change ``UrlSet`` to Hybrid.

## Build for a Dev
Go to ``Starfall/opts.h``, and change ``UrlSet`` to Dev.

## Redirecting every URL
Go to ``Starfall/opts.h``, and change ``UrlSet`` to All.

## Enabling Console for debugging
Go to ``Starfall/opts.h``, and change ``Console`` to true.

# Other
If you use Starfall for a project, please credit me.
